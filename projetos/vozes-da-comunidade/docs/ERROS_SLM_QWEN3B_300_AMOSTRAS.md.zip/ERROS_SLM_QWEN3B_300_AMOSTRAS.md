# Erros do SLM Qwen2.5:3b --- Teste com 300 Amostras

> **Data:** 26 de marco de 2026
> **Modelo:** qwen2.5:3b (1.9 GB) via ollama
> **Corpus:** 300 comentarios do corpus V1 normalizado (TikTokSchemaNormalizer)
> **Aceitos pelo Router:** 157/300 (52.3%)
> **Triplas extraidas:** 156 (1.0/comentario)
> **Tempo:** 437.9s (~2.8s/comentario)

---

## 1. Resumo das Anomalias

| Tipo de Erro | Ocorrencias | Severidade | Impacto |
|-------------|-------------|-----------|---------|
| Polaridade invertida | 3 | **CRITICA** | Triplas NEG aparecem como POS --- contamina indicadores PN e AP simultaneamente |
| Aspecto generico | 3 | MEDIA | "creme", "cremes" sem especificidade --- nao guia decisao de produto |
| Aspecto = Opiniao | presente (n50) | MEDIA | Tripla sem valor informativo (detectado no teste n=50, mitigado pelo novo prompt) |
| Aspecto muito longo | 0 neste teste | BAIXA | Mitigado pelo novo prompt (regra 1: "expressao CURTA e especifica") |

**Taxa de erro critico (polaridade invertida): 3/16 triplas nos indicadores = 19%**

---

## 2. Erros de Polaridade Invertida (CRITICO)

Estes sao os erros mais graves. O SLM classifica como POS comentarios que sao claramente NEG.

### Erro 1: "nao gosto desses creme"

| Campo | Valor |
|-------|-------|
| Aspecto | creme |
| Opiniao | "nao gosto desses creme nao quero nem dado" |
| Polaridade atribuida | **POS** |
| Polaridade correta | **NEG** |
| Frequencia | 4 |
| Evidencia | "nao gosto" + "nao quero nem dado" = rejeicao total |

**Consequencia:** Aparece como atributo de conversao (AP=0.021) E como controverso (C=0.50). Um PM lendo o briefing veria "creme" como ponto positivo quando e rejeicao explicita.

### Erro 2: "ficou muito ruim"

| Campo | Valor |
|-------|-------|
| Aspecto | oliva |
| Opiniao | "ficou muito ruim" |
| Polaridade atribuida | **POS** |
| Polaridade correta | **NEG** |
| Frequencia | 2 |
| Evidencia | "ruim" e inequivocamente negativo |

**Consequencia:** Aparece como controverso (C=1.00). A controversia e real (ha opinioes POS e NEG sobre oliva), mas a tripla individual esta invertida.

### Erro 3: "novex" com polaridade POS nas dores

| Campo | Valor |
|-------|-------|
| Aspecto | novex |
| Opiniao | "amei" (opiniao representativa) |
| Polaridade dominante | **POS** |
| PN | 0.021 |
| Frequencia | 17 |

**Problema:** "novex" aparece simultaneamente como dor (PN=0.021) e atributo (AP=0.096). Isso ocorre porque das 17 mencoes, algumas sao NEG ("acabaram com meu cabelo", "cabelo pegou fogo") mas a polaridade dominante e POS. O aspecto aparece na lista de dores porque tem PN > threshold, mas a opiniao representativa exibida e "amei" (a mais frequente entre as POS).

**Consequencia:** Um PM veria na secao de dores: `[POS] novex -> "amei"`. Isso nao faz sentido --- uma dor nao pode ser positiva.

---

## 3. Erros de Aspecto Generico

| Aspecto | Freq | Opiniao | Problema |
|---------|------|---------|----------|
| creme | 4 | "nao gosto desses creme" | Qual creme? De qual linha? Nao guia decisao |
| cremes | 3 | "otimos" | Idem. Duplicado de "creme" com plural |
| creme | 4 | (controverso) | Aparece em 2 listas por ser generico demais |

**Causa raiz:** O SLM extrai o termo mais superficial do texto em vez de identificar o produto/ingrediente especifico. "Creme da Novex de oliva" deveria gerar aspecto "novex oliva", nao "creme".

---

## 4. Triplas que Aparecem em Multiplas Listas

| Aspecto | Listas | Problema |
|---------|--------|----------|
| novex | dores + atributos | Polaridade mista --- aspecto controverso, mas aparece separado |
| azeite de oliva | atributos + controversos | Correto: e realmente controverso (C=0.44) |
| creme | atributos + controversos | Incorreto: polaridade invertida arrasta para atributos |

---

## 5. O que o SLM Acertou

Nem tudo e erro. O prompt melhorado corrigiu varios problemas do teste anterior (n=50):

| Tripla | Polaridade | Avaliacao |
|--------|-----------|-----------|
| "novex d bambu" + "pegou fogo" | NEG | Correto --- expressao idiomatica interpretada |
| "crespo" + "nao queratina, acido de hialuronico e sem corante" | NEG | Correto --- dor real do segmento cacheadas |
| "cachos de cinema" + "volta nunca" | NEG | Correto --- saudosismo de produto descontinuado |
| "azeite de oliva" + "faz parte da minha infancia" | POS | Correto --- conexao emocional |
| "alecrim" + "meu favorito" | POS | Correto --- preferencia clara |
| "oleo de argam" + "maravilhoso" | POS | Correto |
| "novex" + "amo novex" | POS | Correto |
| "quimica" + "amei" (henegatas) | POS | Correto --- segmento correto tambem |

**Melhoria vs teste n=50:**
- "acabaram com meu cabelo" como POS: **corrigido** (nao aparece mais)
- "pegou fogo" como NEG: **mantido correto**
- Segmentacao HNR: de 1 segmento (tudo indefinido) para **4 segmentos**

---

## 6. Diagnostico: Por que o 3b Falha na Negacao

O padrao e claro: **o Qwen2.5:3b nao processa negacao em portugues de forma confiavel.**

```
"nao gosto"       -> POS  (errado: "nao" inverte o sentido)
"ficou muito ruim" -> POS  (errado: "ruim" e negativo direto)
"nao quero"        -> POS  (errado: rejeicao explicita)
```

Modelos de 3B tem embeddings de negacao mais fracos --- a palavra "nao" nao consegue inverter o sentido da frase no espaco latente com a mesma forca que em modelos maiores. Em portugues informal ("n gosto", "num quero"), o problema e amplificado.

---

## 7. Opcoes de Correcao

### Opcao A: Trocar para Qwen2.5:7b

| Aspecto | Detalhes |
|---------|---------|
| Esforco | Trivial: mudar `SLM_MODEL=qwen2.5:7b` no `.env` |
| Download | ~4.7 GB (vs 1.9 GB do 3b) |
| Tempo/comentario | ~4-5s estimado (vs 2.8s do 3b) |
| Ganho esperado | +10-15% qualidade geral, melhora significativa em negacao |
| Risco | Nenhum --- mesma arquitetura, mesma API |

### Opcao B: Pos-processamento de polaridade

Adicionar validacao apos a extracao do SLM:

```
Se opiniao contem ["nao gost", "ruim", "horrivel", "pessim", "acabou com",
   "acabaram", "pegou fogo", "ressecou", "palha", "quebrou", "nao quero",
   "nao salvou", "caiu", "estrago"]:
   -> forcar polaridade = NEG (override do SLM)
```

| Aspecto | Detalhes |
|---------|---------|
| Esforco | Baixo: ~30 linhas em slm.py ou novo modulo |
| Ganho esperado | Elimina 100% dos erros de negacao com keywords conhecidas |
| Risco | Falsos positivos em frases com negacao dupla ("nao e que nao gostei" = POS) |

### Opcao C: Ambos (A + B)

Trocar para 7b (melhora geral) + pos-processamento (rede de seguranca para negacao).

| Aspecto | Detalhes |
|---------|---------|
| Esforco | Baixo (soma de A + B) |
| Ganho esperado | Qualidade estimada: 70-80% (vs ~55-60% atual) |
| Risco | Pos-processamento pode mascarar erros do modelo que deveriam ser corrigidos no prompt |

### Opcao D: Filtro de confianca mais agressivo

Aumentar `MIN_CONFIDENCE` de 0.5 para 0.7. Triplas com baixa confianca (onde o modelo "chutou") seriam descartadas.

| Aspecto | Detalhes |
|---------|---------|
| Esforco | Trivial: mudar no `.env` |
| Ganho esperado | Menos triplas, mas as restantes com maior precisao |
| Risco | Pode descartar triplas corretas em textos ambiguos |

---

## 8. Problema Estrutural: Aspecto POS na Lista de Dores

Independente do SLM, ha um bug logico no calculador de indicadores:

**Um aspecto com polaridade dominante POS nao deveria aparecer na lista `dores_principais`.**

Hoje, o calculador inclui na lista de dores qualquer aspecto com `score_pn >= threshold`, independente da polaridade dominante. Isso faz com que "novex" (17 mencoes, maioria POS, algumas NEG) apareca como dor com opiniao representativa "amei".

**Correcao sugerida:** Filtrar `dores_principais` para exibir apenas triplas com `polaridade_dominante == NEG`. Idem para `atributos_conversao`: apenas `polaridade_dominante == POS`.

---

## 9. Metricas Comparativas (n=50 vs n=300)

| Metrica | n=50 (corpus bruto) | n=50 (corpus V1) | n=300 (corpus V1) |
|---------|--------------------|--------------------|-------------------|
| Aceitos pelo Router | 48/50 (96%) | 46/50 (92%) | 157/300 (52.3%) |
| Segmentos HNR | 1 | 4 | 4 |
| Dores (PN) | 0 | 10 | 4 |
| Atributos (AP) | 0 | 10 | 9 |
| Controversos | 0 | 1 | 3 |
| Erros polaridade invertida | "acabaram" POS | "acabaram" POS | 3 (creme, oliva) |
| Erros aspecto=opiniao | varios | mitigado | 0 neste teste |

**Evolucao:** O pipeline melhorou significativamente entre as iteracoes. O gap critico (corpus bruto) foi resolvido. Os erros remanescentes sao do SLM, nao da arquitetura.

---

## 10. Recomendacao

A combinacao **Opcao C (7b + pos-processamento) + correcao do bug de dores POS** resolve os 3 problemas criticos:

1. **Polaridade invertida** --- 7b melhora a compreensao de negacao; pos-processamento pega os que escapam
2. **Aspecto generico** --- 7b tende a extrair termos mais especificos (maior capacidade de atencao)
3. **POS na lista de dores** --- correcao no calculador, independente do modelo

Estimativa de qualidade apos correcoes: **70-80%** (vs ~55-60% atual com 3b).
